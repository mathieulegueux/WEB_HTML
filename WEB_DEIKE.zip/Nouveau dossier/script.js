
document.addEventListener("DOMContentLoaded", function() {
    const contactForm = document.querySelector(".contact-form form");
    const confirmationMessage = document.createElement("div");
    confirmationMessage.classList.add("confirmation-message");
    confirmationMessage.textContent = "Votre message a bien été envoyé. Merci !";

    contactForm.addEventListener("submit", function(event) {
        event.preventDefault(); // Empeche d'envoyer le formulaire par défaut (vide)
        contactForm.appendChild(confirmationMessage); // Ajoute le message de confirmation
        setTimeout(function() {
            confirmationMessage.remove(); // Supprime le message après 3 secondes
        }, 3000);
        contactForm.reset(); // Réinitialise le formulaire après l'avoir envoyé
    });
});
